import React, { useState } from 'react'

export default function App() {
  const [events, setEvents] = useState([])

  const addEvent = () => {
    const newEvent = {
      date: prompt('Enter date (YYYY-MM-DD):'),
      student: prompt('Enter student name:'),
      subject: prompt('Enter subject:'),
      lesson: prompt('Enter lesson:'),
      status: 'In Progress',
      grade: '',
      comments: ''
    }
    setEvents([...events, newEvent])
  }

  return (
    <div style={{ fontFamily: 'Arial', padding: '20px' }}>
      <h1>Shan Homeschool Lesson Planner</h1>
      <button onClick={addEvent}>➕ Add Lesson</button>
      <div style={{ marginTop: '20px' }}>
        {events.map((event, index) => (
          <div key={index} style={{ border: '1px solid #ccc', margin: '10px', padding: '10px' }}>
            <p><b>Date:</b> {event.date}</p>
            <p><b>Student:</b> {event.student}</p>
            <p><b>Subject:</b> {event.subject}</p>
            <p><b>Lesson:</b> {event.lesson}</p>
            <p><b>Status:</b> {event.status}</p>
            <p><b>Grade:</b> {event.grade}</p>
            <p><b>Comments:</b> {event.comments}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
